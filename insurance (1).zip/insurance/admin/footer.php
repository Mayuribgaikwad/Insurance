</div>
        <!-- main content area end -->
   <!-- footer area start-->
   <footer>
       <div class="footer-area">
           <p>© Copyright 2021. All right reserved..</p>
       </div>
   </footer>
   <!-- footer area end-->
   </div>
   <!-- page container area end -->


   <!-- bootstrap 4 js -->
   <script src="../assets/js/popper.min.js"></script>
   <script src="../assets/js/bootstrap.min.js"></script>
   <script src="../assets/js/owl.carousel.min.js"></script>
   <script src="../assets/js/metisMenu.min.js"></script>
   <script src="../assets/js/jquery.slimscroll.min.js"></script>
   <script src="../assets/js/jquery.slicknav.min.js"></script>


   <!-- others plugins -->
   <script src="../assets/js/plugins.js"></script>
   <script src="../assets/js/scripts.js"></script>

   <script type="text/javascript" language="javascript" src="../assets/js/datatables.min.js"></script>
<script type="text/javascript" language="javascript" src="../assets/js/dataTables.buttons.min.js"></script>
<script type="text/javascript" language="javascript" src="../assets/js/buttons.flash.min.js"></script>
<script type="text/javascript" language="javascript" src="../assets/js/jszip.min.js"></script>
<script type="text/javascript" language="javascript" src="../assets/js/pdfmake.min.js"></script>
<script type="text/javascript" language="javascript" src="../assets/js/vfs_fonts.js"></script>
<script type="text/javascript" language="javascript" src="../assets/js/buttons.html5.min.js"></script>
<script type="text/javascript" language="javascript" src="../assets/js/buttons.print.min.js"></script>
<script type="text/javascript" language="javascript" src="../assets/js/buttons.colVis.min.js"></script>
   </body>

   </html>