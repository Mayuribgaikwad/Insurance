<?php

define('db_host', 'localhost');
define('db_user', 'root');
define('db_password', "");
define('db_name', 'ims');
?>